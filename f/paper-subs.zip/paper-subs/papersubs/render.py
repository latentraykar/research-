"""Ransom-note subtitles: every word is its own torn paper strip.

Each word gets a random font, a slightly torn edge, a soft drop shadow, a little
paper grain and a small tilt. Words pop in on the exact moment they are spoken
and the phrase stays up until the next one starts.
"""
from __future__ import annotations

import random
import zlib
from dataclasses import dataclass, field
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont

from .align import Word, _norm

FONT_DIR = Path(__file__).parent / "fonts"
FONTS = [
    "NotoSerifDisplay-Black.ttf",
    "NotoSerif-CondensedBold.ttf",
    "NotoSansDisplay-CondensedBlack.ttf",
    "JetBrainsMono-Bold.ttf",
    "Caveat.ttf",            # handwritten - rendered as typed, not uppercased
]
HANDWRITTEN = {"Caveat.ttf"}

PALETTES = {
    "cream":     [(246, 240, 226), (251, 248, 242), (238, 233, 216)],
    "newsprint": [(232, 228, 218), (221, 217, 206), (240, 237, 229)],
    "mixed":     [(246, 240, 226), (251, 248, 242), (232, 228, 218), (238, 233, 216)],
    "kraft":     [(214, 186, 145), (224, 199, 160), (205, 176, 134)],
}
KEY_COLOUR = (233, 196, 106)     # turmeric gold for key words
ACCENT_COLOUR = (168, 208, 186)  # soft sage for your brand word
INK = (29, 26, 22)
POSITIONS = {"bottom": 0.78, "middle": 0.52, "top": 0.20}


@dataclass
class Style:
    position: str = "bottom"            # bottom | middle | top
    size: float = 1.2                   # text scale multiplier
    palette: str = "mixed"              # cream | newsprint | mixed | kraft
    keywords: set = field(default_factory=set)   # gold strips
    accent: set = field(default_factory=set)     # sage strips (brand word)
    uppercase: bool = True
    max_words: int = 5                  # max words per on-screen phrase
    linger: float = 0.55                # seconds a phrase stays after its last word
    seed: int = 7


def _parse_words(s: str) -> set:
    return {_norm(w) for w in s.replace(",", " ").split() if _norm(w)}


def render_strip(word: str, scale: float, colour=None, seed: int = 0, style: Style | None = None) -> Image.Image:
    style = style or Style()
    rnd = random.Random(seed)
    font_name = rnd.choice(FONTS)
    hand = font_name in HANDWRITTEN
    size = (66 if hand else rnd.choice([46, 50, 54])) * scale * style.size
    font = ImageFont.truetype(str(FONT_DIR / font_name), max(int(size), 10))
    disp = word if hand or not style.uppercase else word.upper()

    probe = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    bb = probe.textbbox((0, 0), disp, font=font)
    tw, th = bb[2] - bb[0], bb[3] - bb[1]
    padx, pady = int(22 * scale), int(14 * scale)
    m = int(12 * scale) + 2
    W, H = tw + padx * 2, th + pady * 2
    img = Image.new("RGBA", (W + 2 * m, H + 2 * m), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    colour = colour or rnd.choice(PALETTES.get(style.palette, PALETTES["mixed"]))

    # torn outline: jitter a point every few px along each edge
    x0, y0, x1, y1 = m, m, m + W, m + H
    sx, sy = max(int(14 * scale), 4), max(int(12 * scale), 4)
    j = lambda a, b: int(rnd.randint(a, b) * scale)
    pts = []
    for x in range(x0, x1, sx): pts.append((x + j(-2, 2), y0 + j(-4, 3)))
    for y in range(y0, y1, sy): pts.append((x1 + j(-3, 4), y + j(-2, 2)))
    for x in range(x1, x0, -sx): pts.append((x + j(-2, 2), y1 + j(-3, 4)))
    for y in range(y1, y0, -sy): pts.append((x0 + j(-4, 3), y + j(-2, 2)))

    shadow = Image.new("RGBA", img.size, (0, 0, 0, 0))
    off = (5 * scale, 7 * scale)
    ImageDraw.Draw(shadow).polygon([(px + off[0], py + off[1]) for px, py in pts], fill=(20, 15, 10, 110))
    img.alpha_composite(shadow.filter(ImageFilter.GaussianBlur(4 * scale)))
    d.polygon(pts, fill=colour + (255,))
    for _ in range(int(W * H / (300 * scale * scale))):       # paper grain
        d.point((rnd.randint(x0, x1 - 1), rnd.randint(y0, y1 - 1)), fill=(120, 112, 100, rnd.randint(15, 45)))
    d.text((x0 + padx - bb[0], y0 + pady - bb[1]), disp, font=font, fill=INK)
    return img.rotate(rnd.uniform(-4.5, 4.5), expand=True, resample=Image.BICUBIC)


def group_phrases(words: list[Word], max_words: int = 5) -> list[list[Word]]:
    phrases, cur = [], []
    for i, w in enumerate(words):
        if cur and w.start - cur[-1].end > 0.8:          # a real pause starts a new phrase
            phrases.append(cur); cur = []
        cur.append(w)
        t = w.text
        nxt = words[i + 1].text if i + 1 < len(words) else ""
        ends = (".", "!", "?", "—", "…", ":", ";")
        # don't strand a sentence's last word alone on the next phrase
        full = len(cur) >= max_words and not (nxt.endswith(ends) and len(cur) == max_words)
        if t.endswith(ends) or (t.endswith(",") and len(cur) >= 3) or full or len(cur) > max_words:
            phrases.append(cur); cur = []
    if cur:
        phrases.append(cur)
    return phrases


def build_track(words: list[Word], width: int, height: int, duration: float, workdir: Path,
                style: Style | None = None) -> Path:
    """Render every on-screen state as a transparent full-frame PNG and write an
    ffmpeg concat list that plays them at the right times. Returns the list path."""
    style = style or Style()
    workdir = Path(workdir); workdir.mkdir(parents=True, exist_ok=True)
    scale = min(width, height) / 1080
    overlap = int(30 * scale)
    row_h = int(96 * scale * style.size)
    max_row = int(width * 0.89)
    base_y = int(height * POSITIONS.get(style.position, 0.78))
    keys, accent = set(style.keywords), set(style.accent)

    blank = workdir / "blank.png"
    Image.new("RGBA", (width, height), (0, 0, 0, 0)).save(blank)
    phrases = group_phrases(words, style.max_words)
    timeline: list[tuple[Path, float, float]] = []   # (png, start, end)
    widx = 0

    for n, p in enumerate(phrases):
        nxt = phrases[n + 1][0].start if n + 1 < len(phrases) else duration
        p_end = min(p[-1].end + style.linger, nxt - 0.02, duration)
        strips = []
        for w in p:
            c = _norm(w.text)
            col = ACCENT_COLOUR if c in accent else KEY_COLOUR if c in keys else None
            seed = zlib.crc32(f"{style.seed}:{widx}:{w.text}".encode())
            strips.append(render_strip(w.text, scale, col, seed, style)); widx += 1
        # wrap into centred rows, strips overlap a little like glued clippings
        rows, row, roww = [], [], 0
        for s in strips:
            if row and roww + s.width - overlap > max_row:
                rows.append(row); row, roww = [], 0
            row.append(s); roww += s.width - overlap
        rows.append(row)
        placed, y = [], base_y - (len(rows) - 1) * row_h
        if style.position == "top":
            y = base_y
        for r in rows:
            total = sum(s.width for s in r) - overlap * (len(r) - 1)
            x = (width - total) // 2
            for s in r:
                placed.append((s, x, y - s.height // 2)); x += s.width - overlap
            y += row_h
        # one state per word reveal: state k shows words 0..k
        canvas = Image.new("RGBA", (width, height), (0, 0, 0, 0))
        for k, (s, x, y0) in enumerate(placed):
            canvas.alpha_composite(s, (max(x, 0), max(y0, 0)))
            st = p[k].start
            en = p[k + 1].start if k + 1 < len(p) else p_end
            if en - st <= 0.0:
                continue
            png = workdir / f"state_{n:04d}_{k:02d}.png"
            canvas.save(png, optimize=False, compress_level=3)
            timeline.append((png, st, en))

    # concat list: blanks fill every gap so timestamps stay exact
    lines, t = ["ffconcat version 1.0"], 0.0
    def add(path: Path, dur: float):
        if dur > 0.0005:
            lines.append(f"file '{path.as_posix()}'")
            lines.append(f"duration {dur:.4f}")
    for png, st, en in timeline:
        st = max(st, t)
        add(blank, st - t)
        add(png, en - st)
        t = max(t, en)
    add(blank, max(duration - t, 0.04))
    lines.append(f"file '{blank.as_posix()}'")   # concat demuxer needs the last file repeated
    out = workdir / "track.ffconcat"
    out.write_text("\n".join(lines) + "\n")
    return out
