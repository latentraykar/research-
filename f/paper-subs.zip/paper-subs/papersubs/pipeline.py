"""Video + script (+ optional voiceover) -> video with paper-strip subtitles."""
from __future__ import annotations

import json
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Callable, Optional

from .align import align_script, transcribe
from .render import Style, build_track

Progress = Callable[[str, float], None]   # (stage, 0..1 overall)


def _need(binary: str):
    if not shutil.which(binary):
        raise RuntimeError(f"'{binary}' not found on PATH. Install ffmpeg (it ships ffprobe too) and try again.")


def probe(path: str) -> dict:
    _need("ffprobe")
    out = subprocess.run(["ffprobe", "-v", "error", "-print_format", "json", "-show_streams", "-show_format", path],
                         capture_output=True, text=True, check=True).stdout
    info = json.loads(out)
    v = next((s for s in info["streams"] if s["codec_type"] == "video"), None)
    a = next((s for s in info["streams"] if s["codec_type"] == "audio"), None)
    res = {"duration": float(info["format"].get("duration", 0) or 0), "has_audio": a is not None}
    if v:
        w, h = int(v["width"]), int(v["height"])
        rot = 0
        for sd in v.get("side_data_list", []) or []:
            if "rotation" in sd:
                rot = int(float(sd["rotation"]))
        rot = rot or int(v.get("tags", {}).get("rotate", 0) or 0)
        if abs(rot) % 180 == 90:
            w, h = h, w
        res.update(width=w - w % 2, height=h - h % 2)
    return res


def _extract_wav(src: str, dst: Path):
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", src, "-vn", "-ac", "1", "-ar", "16000", str(dst)], check=True)


def make(video: str, script: str = "", out: str = "out.mp4", voiceover: Optional[str] = None,
         style: Optional[Style] = None, model_size: str = "base", language: Optional[str] = None,
         original_volume: float = 0.25, loudness: float = -14.0, progress: Progress = lambda s, p: None,
         workdir: Optional[str] = None) -> dict:
    """Run the whole thing. Returns {'out', 'words', 'duration'}."""
    _need("ffmpeg")
    style = style or Style()
    vinfo = probe(video)
    if "width" not in vinfo:
        raise ValueError("That file has no video stream.")
    audio_src = voiceover or video
    if not voiceover and not vinfo["has_audio"]:
        raise ValueError("The video has no audio. Add a voiceover file so the words can be timed.")

    tmp = Path(workdir) if workdir else Path(tempfile.mkdtemp(prefix="papersubs_"))
    tmp.mkdir(parents=True, exist_ok=True)
    duration = vinfo["duration"]
    if voiceover:
        duration = max(duration, probe(voiceover)["duration"])

    progress("listening", 0.02)
    wav = tmp / "speech.wav"
    _extract_wav(audio_src, wav)
    heard = transcribe(str(wav), model_size=model_size, language=language, script_hint=script,
                       progress=lambda p: progress("listening", 0.02 + 0.48 * p))
    words = align_script(script, heard) if script.strip() else heard
    (tmp / "words.json").write_text(json.dumps([w.__dict__ for w in words], indent=1))

    progress("cutting paper", 0.52)
    track = build_track(words, vinfo["width"], vinfo["height"], duration, tmp / "strips", style)

    progress("rendering", 0.60)
    W, H = vinfo["width"], vinfo["height"]
    pad = max(duration - vinfo["duration"], 0)
    vchain = f"[0:v]scale={W}:{H},setsar=1"
    if pad > 0.01:
        vchain += f",tpad=stop_mode=clone:stop_duration={pad:.3f}"   # hold last frame while the VO finishes
    cmd = ["ffmpeg", "-y", "-v", "error", "-nostats", "-progress", "pipe:1", "-i", video]
    fc = [vchain + "[base]"]
    if voiceover:
        cmd += ["-i", voiceover]
        fc.append("[1:a]aresample=48000,aformat=channel_layouts=stereo,asplit=2[vo][key]")
        if vinfo["has_audio"] and original_volume > 0:
            fc.append(f"[0:a]aresample=48000,aformat=channel_layouts=stereo,volume={original_volume}[bg]")
            fc.append("[bg][key]sidechaincompress=threshold=0.02:ratio=8:attack=20:release=400[bgd]")
            fc.append("[bgd][vo]amix=inputs=2:duration=longest:normalize=0,alimiter=limit=0.95[aout]")
        else:
            fc.append("[key]anullsink")
            fc.append("[vo]anull[aout]")
    else:
        fc.append("[0:a]anull[aout]")
    if loudness:
        fc.append(f"[aout]loudnorm=I={loudness}:TP=-1.5:LRA=11,aresample=48000[afinal]")
        amap = "[afinal]"
    else:
        amap = "[aout]"
    ti = 2 if voiceover else 1
    cmd += ["-f", "concat", "-safe", "0", "-i", str(track)]
    fc.append(f"[base][{ti}:v]overlay=0:0:eof_action=pass:format=auto,format=yuv420p[vout]")
    cmd += ["-filter_complex", ";".join(fc), "-map", "[vout]", "-map", amap,
            "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-pix_fmt", "yuv420p",
            "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", "-t", f"{duration:.3f}", str(out)]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    for line in proc.stdout:
        if line.startswith("out_time_us=") and duration > 0:
            try:
                t = int(line.split("=", 1)[1]) / 1e6
                progress("rendering", 0.60 + 0.39 * min(t / duration, 1.0))
            except ValueError:
                pass
    err = proc.stderr.read()
    if proc.wait() != 0:
        raise RuntimeError(f"ffmpeg failed:\n{err[-1500:]}")
    progress("done", 1.0)
    if not workdir:
        shutil.rmtree(tmp, ignore_errors=True)
    return {"out": str(out), "words": len(words), "duration": round(duration, 2)}
