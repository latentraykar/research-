"""paper-subs: ransom-note paper-strip subtitles, fully local."""
from .pipeline import make
from .render import Style

__version__ = "1.0.0"
__all__ = ["make", "Style"]
