"""Word timing: local speech recognition (faster-whisper) + alignment to your script.

Whisper gives us *when* each word was spoken. Your script gives us *how* it is
spelled. We line the two up with a sequence match, so the words on screen are
exactly your script (names, brand spellings, punctuation) with real timings.
"""
from __future__ import annotations

import difflib
import re
from dataclasses import dataclass
from typing import Callable, Optional

_MODEL_CACHE: dict = {}


@dataclass
class Word:
    text: str          # display text (script spelling, punctuation kept)
    start: float       # seconds
    end: float         # seconds


def _norm(t: str) -> str:
    return re.sub(r"[^\w]", "", t.lower(), flags=re.UNICODE)


def script_tokens(script: str) -> list[str]:
    return [t for t in script.replace("—", " — ").split() if t.strip()]


def _load_model(size: str, device: str):
    key = (size, device)
    if key not in _MODEL_CACHE:
        from faster_whisper import WhisperModel
        compute = "int8" if device == "cpu" else "float16"
        _MODEL_CACHE[key] = WhisperModel(size, device=device, compute_type=compute)
    return _MODEL_CACHE[key]


def transcribe(audio_path: str, model_size: str = "base", language: Optional[str] = None,
               device: str = "cpu", script_hint: str = "",
               progress: Callable[[float], None] = lambda p: None) -> list[Word]:
    """Speech -> list of Word with timestamps. Runs fully offline after the first model download."""
    model = _load_model(model_size, device)
    progress(0.15)   # model ready; whisper reports the rest segment by segment
    segments, info = model.transcribe(
        audio_path,
        language=language or None,
        word_timestamps=True,
        vad_filter=True,
        initial_prompt=script_hint[:800] or None,  # nudges spelling of names towards the script
    )
    dur = max(info.duration, 0.01)
    out: list[Word] = []
    for seg in segments:
        for w in seg.words or []:
            if w.word.strip():
                out.append(Word(w.word.strip(), float(w.start), float(w.end)))
        progress(min(seg.end / dur, 1.0))
    progress(1.0)
    return out


def align_script(script: str, heard: list[Word]) -> list[Word]:
    """Map every script token onto the recognised words' timings.

    equal   -> copy timing
    replace -> spread the heard span across the script words by character length
    delete  -> (script word never heard) interpolate between neighbours
    """
    toks = script_tokens(script)
    if not toks:
        return heard
    if not heard:
        raise ValueError("No speech found in the audio - nothing to time the script against.")

    a = [_norm(t) for t in toks]
    b = [_norm(w.text) for w in heard]
    times: list[Optional[tuple[float, float]]] = [None] * len(toks)
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    for op, i1, i2, j1, j2 in sm.get_opcodes():
        if op == "equal":
            for k in range(i2 - i1):
                times[i1 + k] = (heard[j1 + k].start, heard[j1 + k].end)
        elif op == "replace":
            s, e = heard[j1].start, heard[j2 - 1].end
            lens = [max(len(a[i]), 1) for i in range(i1, i2)]
            tot, acc = sum(lens), 0
            for n, i in enumerate(range(i1, i2)):
                ws = s + (e - s) * acc / tot
                acc += lens[n]
                times[i] = (ws, s + (e - s) * acc / tot)

    # fill gaps (script words the recogniser missed) by interpolation
    n = len(toks)
    i = 0
    while i < n:
        if times[i] is not None:
            i += 1
            continue
        j = i
        while j < n and times[j] is None:
            j += 1
        left = times[i - 1][1] if i > 0 else None
        right = times[j][0] if j < n else None
        count = j - i
        if left is None and right is None:
            left, right = 0.0, 0.35 * count
        elif left is None:
            left = max(0.0, right - 0.35 * count)
        elif right is None:
            right = left + 0.35 * count
        step = max((right - left) / count, 0.05)
        for k in range(count):
            times[i + k] = (left + k * step, left + (k + 1) * step)
        i = j

    words, last = [], 0.0
    for t, (s, e) in zip(toks, times):
        s = max(s, last)
        e = max(e, s + 0.05)
        words.append(Word(t, round(s, 3), round(e, 3)))
        last = s
    return words
