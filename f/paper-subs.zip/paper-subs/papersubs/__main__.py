"""CLI: python -m papersubs render --video in.mp4 --script script.txt -o out.mp4"""
import argparse
import sys
from pathlib import Path

from .pipeline import make
from .render import PALETTES, POSITIONS, Style, _parse_words


def main(argv=None):
    ap = argparse.ArgumentParser(prog="papersubs", description="Ransom-note paper-strip subtitles for your reels.")
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("render", help="burn paper subtitles into a video")
    r.add_argument("--video", required=True, help="input video (mp4/mov/webm...)")
    r.add_argument("--script", default="", help="script as a .txt file or a quoted string (optional: without it the words are auto-transcribed)")
    r.add_argument("--vo", default=None, help="optional voiceover audio; it's timed and mixed over the video")
    r.add_argument("-o", "--out", default="papersubs_out.mp4")
    r.add_argument("--keywords", default="", help="words on gold strips, e.g. 'sky,chart,care'")
    r.add_argument("--accent", default="", help="brand word(s) on a sage strip")
    r.add_argument("--position", choices=list(POSITIONS), default="bottom")
    r.add_argument("--size", type=float, default=1.2, help="text scale, 0.6-1.8")
    r.add_argument("--palette", choices=list(PALETTES), default="mixed")
    r.add_argument("--max-words", type=int, default=5, help="max words on screen at once")
    r.add_argument("--keep-case", action="store_true", help="don't uppercase")
    r.add_argument("--original-volume", type=float, default=0.25, help="video's own audio under the VO (0 mutes)")
    r.add_argument("--loudness", type=float, default=-14, help="normalise output to this LUFS (reels ~ -14); 0 = leave audio as is")
    r.add_argument("--model", default="base", help="whisper model: tiny | base | small | medium")
    r.add_argument("--language", default=None, help="e.g. en, hi (auto-detect if omitted)")
    r.add_argument("--seed", type=int, default=7, help="change for a different random look")
    a = ap.parse_args(argv)

    script = a.script
    if script and Path(script).is_file():
        script = Path(script).read_text(encoding="utf-8")
    style = Style(position=a.position, size=a.size, palette=a.palette, keywords=_parse_words(a.keywords),
                  accent=_parse_words(a.accent), uppercase=not a.keep_case, max_words=a.max_words, seed=a.seed)

    last = {"s": None}
    def progress(stage, p):
        if last["s"] not in (None, stage):
            print()
        last["s"] = stage
        bar = "#" * int(p * 30)
        print(f"\r{stage:<14} [{bar:<30}] {int(p * 100):3d}%", end="", flush=True)
    res = make(a.video, script, a.out, voiceover=a.vo, style=style, model_size=a.model,
               language=a.language, original_volume=a.original_volume, loudness=a.loudness, progress=progress)
    print(f"\ndone -> {res['out']}  ({res['words']} words, {res['duration']}s)")


if __name__ == "__main__":
    sys.exit(main())
