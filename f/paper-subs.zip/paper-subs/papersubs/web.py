"""Local web UI (FastAPI). Everything runs on your machine; nothing is uploaded anywhere."""
from __future__ import annotations

import io
import queue
import shutil
import threading
import time
import traceback
import uuid
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, Response
from fastapi.staticfiles import StaticFiles
from PIL import Image

from .pipeline import make
from .render import PALETTES, Style, _parse_words, render_strip

HERE = Path(__file__).parent
OUT_DIR = Path.cwd() / "outputs"
app = FastAPI(title="paper-subs")
app.mount("/fonts", StaticFiles(directory=HERE / "fonts"), name="fonts")

JOBS: dict[str, dict] = {}
Q: "queue.Queue[str]" = queue.Queue()


def _worker():
    while True:
        jid = Q.get()
        job = JOBS[jid]
        job.update(status="running", started=time.time())
        try:
            def prog(stage, p):
                job.update(stage=stage, progress=round(p, 3))
            res = make(job["video"], job["script"], job["out"], voiceover=job["vo"], style=job["style"],
                       model_size=job["model"], language=job["language"] or None,
                       original_volume=job["original_volume"], loudness=job["loudness"], progress=prog, workdir=str(job["dir"] / "work"))
            shutil.rmtree(job["dir"] / "work", ignore_errors=True)
            job.update(status="done", progress=1.0, stage="done", words=res["words"], duration=res["duration"],
                       took=round(time.time() - job["started"], 1))
        except Exception as e:  # surface the reason in the UI
            traceback.print_exc()
            job.update(status="error", error=str(e))


threading.Thread(target=_worker, daemon=True).start()


def _save(up: Optional[UploadFile], dest: Path) -> Optional[str]:
    if not up or not up.filename:
        return None
    path = dest / ("in_" + Path(up.filename).name.replace(" ", "_"))
    with open(path, "wb") as f:
        shutil.copyfileobj(up.file, f)
    return str(path)


@app.get("/", response_class=HTMLResponse)
def index():
    return (HERE / "static" / "index.html").read_text(encoding="utf-8")


@app.get("/api/sample")
def sample(text: str = "cut from paper", keywords: str = "", accent: str = "", palette: str = "mixed",
           uppercase: bool = True, seed: int = 7, size: float = 1.2):
    """Live look preview for the settings panel."""
    style = Style(palette=palette if palette in PALETTES else "mixed", uppercase=uppercase, size=size,
                  keywords=_parse_words(keywords), accent=_parse_words(accent), seed=seed)
    from .render import ACCENT_COLOUR, KEY_COLOUR, _norm
    import zlib
    strips = []
    for i, w in enumerate(text.split()[:8] or ["paper"]):
        c = _norm(w)
        col = ACCENT_COLOUR if c in style.accent else KEY_COLOUR if c in style.keywords else None
        strips.append(render_strip(w, 0.8, col, zlib.crc32(f"{seed}:{i}:{w}".encode()), style))
    ov = 24
    W = sum(s.width for s in strips) - ov * (len(strips) - 1)
    H = max(s.height for s in strips)
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    x = 0
    for s in strips:
        img.alpha_composite(s, (x, (H - s.height) // 2)); x += s.width - ov
    buf = io.BytesIO(); img.save(buf, "PNG")
    return Response(buf.getvalue(), media_type="image/png", headers={"Cache-Control": "no-store"})


@app.post("/api/jobs")
async def create_job(video: UploadFile = File(...), voiceover: Optional[UploadFile] = File(None),
                     script: str = Form(""), keywords: str = Form(""), accent: str = Form(""),
                     position: str = Form("bottom"), size: float = Form(1.0), palette: str = Form("mixed"),
                     max_words: int = Form(5), uppercase: bool = Form(True), original_volume: float = Form(0.25), loudness: float = Form(-14),
                     model: str = Form("base"), language: str = Form(""), seed: int = Form(7)):
    jid = uuid.uuid4().hex[:10]
    d = OUT_DIR / jid
    d.mkdir(parents=True, exist_ok=True)
    v = _save(video, d)
    if not v:
        raise HTTPException(400, "video is required")
    vo = _save(voiceover, d)
    stem = Path(video.filename).stem.replace(" ", "_")
    style = Style(position=position, size=size, palette=palette, keywords=_parse_words(keywords),
                  accent=_parse_words(accent), uppercase=uppercase, max_words=max(1, min(max_words, 8)), seed=seed)
    JOBS[jid] = dict(id=jid, status="queued", stage="queued", progress=0.0, dir=d, video=v, vo=vo, script=script,
                     style=style, model=model, language=language, original_volume=original_volume, loudness=loudness,
                     out=str(d / f"{stem}_papersubs.mp4"), filename=f"{stem}_papersubs.mp4")
    Q.put(jid)
    return {"id": jid}


@app.get("/api/jobs/{jid}")
def job_status(jid: str):
    j = JOBS.get(jid)
    if not j:
        raise HTTPException(404, "no such job")
    return {k: j.get(k) for k in ("id", "status", "stage", "progress", "error", "words", "duration", "took", "filename")}


@app.get("/api/jobs/{jid}/video")
def job_video(jid: str, download: bool = False):
    j = JOBS.get(jid)
    if not j or j["status"] != "done":
        raise HTTPException(404, "not ready")
    return FileResponse(j["out"], media_type="video/mp4", filename=j["filename"] if download else None)
