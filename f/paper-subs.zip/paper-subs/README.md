# paper subs

**Ransom-note subtitles for your reels.** Every word is cut out of paper and glued on screen the moment it's spoken.

Drop in a video and your script (and a voiceover, if you have one). It listens, finds the exact moment each word is said, and gives you back the edited video. Runs 100% on your machine: no API keys, no uploads, no subscriptions.

<p align="center">
  <img src="docs/preview.jpg" width="720" alt="paper subs frames">
</p>

▶️ **Demo:** [`docs/demo.mp4`](docs/demo.mp4), made with this tool from a silent clip + a voiceover + the script.

---

## What it does

- **Word-perfect timing, offline.** Local speech recognition ([faster-whisper](https://github.com/SYSTRAN/faster-whisper)) hears when every word lands; your script is then aligned onto those timings, so what's on screen is spelled exactly like your script (names, brands, punctuation).
- **Three ways in:**
  1. `video + script` - times the words from the video's own audio
  2. `video + voiceover + script` - times the VO, mixes it over the video and ducks the original audio under it
  3. `video` only - no script? it auto-transcribes
- **The paper look.** Torn edges, soft shadow, paper grain, a random font per word, a little tilt. Key words on **gold** strips, your brand word on a **sage** strip.
- **Web app + CLI.** A clean local web UI with a live look preview, progress and one-click download, or one command in the terminal.

## Setup

You need **Python 3.9+** and **ffmpeg** on your PATH.

<details>
<summary>Don't have ffmpeg?</summary>

- macOS: `brew install ffmpeg`
- Windows: `winget install ffmpeg` (then open a new terminal)
- Linux: `sudo apt install ffmpeg`

Check with `ffmpeg -version`.
</details>

```bash
git clone https://github.com/<you>/paper-subs.git
cd paper-subs

python -m venv .venv
# macOS / Linux
source .venv/bin/activate
# Windows
.venv\Scripts\activate

pip install -r requirements.txt
```

The first run downloads the speech model once (~150 MB for `base`). After that it works offline.

## Use it: web app

```bash
python app.py
```

Your browser opens `http://127.0.0.1:7860`.

1. **Drop your video** (mp4, mov, webm).
2. **Optional: drop a voiceover** (mp3, wav, m4a). Skip it if the video already has the voice.
3. **Paste your script** (or `load .txt`). Leave it empty to auto-transcribe.
4. **Style it:** gold words, brand word, position, paper colour, size, words per phrase. The preview strip updates live; hit **re-roll look** for a different random mix of fonts and tears.
5. Hit **cut & glue**, watch it render, then **download mp4**.

Finished videos also sit in `./outputs/<job-id>/`.

## Use it: command line

```bash
# video that already has the voice in it
python -m papersubs render --video reel.mp4 --script script.txt -o reel_subs.mp4

# silent footage + separate voiceover
python -m papersubs render --video broll.mp4 --vo voiceover.mp3 --script script.txt \
    --keywords "paper, exact, laptop" --accent subs -o final.mp4

# no script, just transcribe
python -m papersubs render --video talking_head.mp4 -o out.mp4
```

| option | default | what it does |
|---|---|---|
| `--script` | none | `.txt` file or a quoted string. Empty = auto-transcribe |
| `--vo` | none | voiceover audio, timed and mixed over the video |
| `--keywords` | none | words on gold strips (comma or space separated) |
| `--accent` | none | brand word(s) on a sage strip |
| `--position` | `bottom` | `bottom`, `middle`, `top` |
| `--size` | `1.2` | text scale, 0.6-1.8 |
| `--palette` | `mixed` | `mixed`, `cream`, `newsprint`, `kraft` |
| `--max-words` | `5` | most words on screen at once |
| `--keep-case` | off | don't uppercase |
| `--original-volume` | `0.25` | the video's own audio under the VO (0 mutes it) |
| `--loudness` | `-14` | normalise audio to reel loudness in LUFS; `0` leaves it as is |
| `--model` | `base` | `tiny` (fast) / `base` / `small` / `medium` (most accurate) |
| `--language` | auto | e.g. `en`, `hi` |
| `--seed` | `7` | change it for a different random look |

Works at any resolution and aspect ratio (9:16, 1:1, 16:9); strips scale with the frame. If the voiceover is longer than the video, the last frame holds until it finishes.

## How it works

```
audio ──► faster-whisper (word timestamps) ──┐
script ──────────────────────────────────────┴─► sequence alignment ─► word timings
word timings ─► Pillow: one torn strip per word, phrase layout ─► transparent frames
video + frames (+ VO, ducked mix) ─► ffmpeg overlay ─► your mp4
```

- **Alignment** (`papersubs/align.py`): whisper's words and your script's words are matched with a diff. Matching words take whisper's timing; misheard stretches are spread by word length; words it missed entirely are interpolated between neighbours.
- **Strips** (`papersubs/render.py`): each word gets a jittered torn polygon, blurred drop shadow, grain and a ±4.5° tilt. Phrases break at sentence ends, long pauses or the word cap, wrap into centred rows and stay up until just before the next phrase.
- **Compose** (`papersubs/pipeline.py`): each on-screen state is one transparent PNG, played as a single timed image track and overlaid in one ffmpeg pass, so a 3-minute video is as stable as a 15-second one.

## Troubleshooting

- **`'ffmpeg' not found`**: install it (see Setup) and open a new terminal.
- **Words land a little early/late**: try `--model small`, and set `--language` if auto-detect guesses wrong.
- **A word shows the wrong spelling**: that's from your script; fix it there. Without a script you get whisper's spelling.
- **Hindi / Hinglish**: use `--model small` or `medium` with `--language hi`. Write the script the way it's spoken.
- **Slow on a long video**: it's the speech model; `--model tiny` is several times faster. Rendering is plain ffmpeg.
- **Apple Silicon / Windows**: runs on CPU out of the box, no GPU needed.

## Project layout

```
paper-subs/
├── app.py                 # python app.py -> local web app
├── papersubs/
│   ├── align.py           # faster-whisper + script alignment
│   ├── render.py          # paper strip renderer + phrase layout
│   ├── pipeline.py        # end-to-end: probe, time, render, ffmpeg
│   ├── web.py             # FastAPI backend
│   ├── __main__.py        # CLI
│   ├── static/index.html  # the web UI
│   └── fonts/             # bundled OFL fonts + licence
├── docs/                  # demo + preview
├── requirements.txt
└── LICENSE
```

## Licence

Code: [MIT](LICENSE). Fonts in `papersubs/fonts/` (Noto Serif Display, Noto Serif, Noto Sans Display, JetBrains Mono, Caveat) are under the [SIL Open Font License 1.1](papersubs/fonts/OFL.txt).
